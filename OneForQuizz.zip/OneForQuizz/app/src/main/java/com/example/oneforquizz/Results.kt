package com.example.oneforquizz

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        val results = intent.getSerializableExtra("results") as Map<Int, Boolean>

        val textView: TextView = findViewById(R.id.results)
        textView.text = results.entries.joinToString(separator = "\n") { (questionId, isCorrect) ->
            "Question ID $questionId Got: ${if (isCorrect) "Correct" else "Wrong"}"
        }
    }
}