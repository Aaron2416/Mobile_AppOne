package com.example.oneforquizz

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class MyFragment : Fragment() {

    private lateinit var buttonA: Button
    private lateinit var buttonB: Button
    private lateinit var buttonC: Button
    private lateinit var buttonD: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.activity_quiz, container, false)

        buttonA = view.findViewById(R.id.Ans_A)
        buttonB = view.findViewById(R.id.Ans_B)
        buttonC = view.findViewById(R.id.Ans_C)
        buttonD = view.findViewById(R.id.Ans_D)

        val clickListener = View.OnClickListener { button ->
            // reset all buttons to default
            buttonA.setBackgroundResource(R.drawable.button_background)
            buttonB.setBackgroundResource(R.drawable.button_background)
            buttonC.setBackgroundResource(R.drawable.button_background)
            buttonD.setBackgroundResource(R.drawable.button_background)

            // set the clicked button as selected
            button.setBackgroundResource(R.drawable.button_pressed)
        }

        buttonA.setOnClickListener(clickListener)
        buttonB.setOnClickListener(clickListener)
        buttonC.setOnClickListener(clickListener)
        buttonD.setOnClickListener(clickListener)

        return view
    }
}