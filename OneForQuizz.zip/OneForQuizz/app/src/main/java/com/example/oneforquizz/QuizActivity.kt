package com.example.oneforquizz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    lateinit var quiz: Quiz
    lateinit var selectedAnswers: MutableMap<Int, Int>
    var currentQuestionIndex = 0
    var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        selectedAnswers = intent.getSerializableExtra("selectedAnswers") as? MutableMap<Int, Int> ?: mutableMapOf()
        // Start Quiz
        quiz = Quiz()

        findViewById<Button>(R.id.submit).setOnClickListener {
            checkAnswers()
        }

        findViewById<Button>(R.id.next).setOnClickListener {
            moveToNextQuestion()
        }


        // button clicks
        val AnsA: Button = findViewById(R.id.Ans_A)
        AnsA.setOnClickListener { checkAnswer(0) }

        val AnsB: Button = findViewById(R.id.Ans_B)
        AnsB.setOnClickListener { checkAnswer(1) }

        val AnsC: Button = findViewById(R.id.Ans_C)
        AnsC.setOnClickListener { checkAnswer(2) }

        val AnsD: Button = findViewById(R.id.Ans_D)
        AnsD.setOnClickListener { checkAnswer(3) }

        // submit button click
        findViewById<Button>(R.id.submit).setOnClickListener {
            checkAnswers()
            moveToNextQuestion()
        }

        setQuestion()
    }

    private fun setQuestion() {
        if(currentQuestionIndex < quiz.quizQuestions.size) {
            findViewById<TextView>(R.id.question).apply {
                this.text = quiz.quizQuestions[currentQuestionIndex]
            }
            val choices = quiz.quizChoices[currentQuestionIndex]
            findViewById<Button>(R.id.Ans_A).text = choices[0]
            findViewById<Button>(R.id.Ans_B).text = choices[1]
            findViewById<Button>(R.id.Ans_C).text = choices[2]
            findViewById<Button>(R.id.Ans_D).text = choices[3]

            findViewById<TextView>(R.id.total_questions).text = "Question ${currentQuestionIndex + 1} of ${quiz.quizQuestions.size}"
        } else {
            endQuiz()
        }
    }

    private fun checkAnswer(selectedAnswerIndex: Int) {
        if(selectedAnswerIndex == quiz.quizAnswers[currentQuestionIndex]) {
            score++
        }
    }

    private fun checkAnswers() {
        val results = mutableMapOf<Int, Boolean>()
        for ((questionId, selectedAnswerIndex) in selectedAnswers) {
            if (quiz.quizAnswers[questionId] == selectedAnswerIndex) {
                score++
                results[questionId] = true
            } else {
                results[questionId] = false
            }
        }
        val intent = Intent(this, ResultActivity::class.java)
        intent.putExtra("results", results as java.io.Serializable)
        startActivity(intent)
    }

    private fun moveToNextQuestion() {
        currentQuestionIndex++
        setQuestion()
    }

    private fun endQuiz() {
        Toast.makeText(this, "Quiz ended. Your score is $score out of ${quiz.quizQuestions.size}.", Toast.LENGTH_LONG).show()
    }
}