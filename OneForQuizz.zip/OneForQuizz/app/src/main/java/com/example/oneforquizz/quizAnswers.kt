package com.example.oneforquizz



class Quiz {
    val quizQuestions = arrayOf(
        "what is howard's favorite color?",
        "what is howard's favorite food?",
        "what is howard's coding rules called?",
        "what is howard's favorite programming language?",
        "does he have any faith in this coding generation?",
        "how many more years dose he have left teaching?",
        "when does his class end?",
        "what is his favorite saying?",
        "how good is his coding jokes?",

        )

    val quizChoices = arrayOf(
        arrayOf("black", "blue", "green", "purple"),
        arrayOf("burgers", "subway", "pasta", "hot dogs"),
        arrayOf("the 10 commandments", "don't code", "rules of coding", "all of the above"), // choices for third question
        arrayOf("Java", "Python", "Kotlin", "Pearl"),
        arrayOf("Yes", "Absolutely none", "Only a little", "Not at all"),
        arrayOf("Just this semester", "Two years", "One year", "Indefinitely"),
        arrayOf("When we get the questions right", "After three hours", "When he's not disappointed", "One hour"),
        arrayOf("How many things should a method do?", "Come on guys", "Sighs", "Y'all should know this"),
        arrayOf("Unfunny", "6 out of 10", "Bad", "Alright")
    )

    //uses the index of the question to get the index of the answer
    val quizAnswers = arrayOf(
        1,
        1,
        0,
        3,
        1,
        3,
        2,
        0,
        1,
    )
}