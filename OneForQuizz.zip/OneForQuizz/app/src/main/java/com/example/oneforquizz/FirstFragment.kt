package com.example.oneforquizz

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.oneforquizz.databinding.FragmentFirstBinding

class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    private var selectedAnswers: MutableMap<Int, String> = mutableMapOf()


    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)

        val exitButton: Button = _binding!!.root.findViewById(R.id.exit)
        exitButton.setOnClickListener {
            val intent = Intent(activity, QuizActivity::class.java)
            intent.putExtra("selectedAnswers", selectedAnswers as java.io.Serializable)
            startActivity(intent)
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        _binding?.buttonFirst?.setOnClickListener {
            clickedAnswerButton(it)
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        // Set the binding reference to null
        _binding?.let {
            _binding = null
        }
    }


    private fun clickedAnswerButton(button: View) {
        val answerIndex = when(button.id) {
            R.id.Ans_A -> 0
            R.id.Ans_B -> 1
            R.id.Ans_C -> 2
            R.id.Ans_D -> 3
            else -> -1
    }


    }
}

