package com.example.oneforquizz

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var selectedQuiz: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupQuizSpinner()
        setupStartButton()
    }

    private fun setupQuizSpinner() {
        val spinnerQuiz: Spinner = findViewById(R.id.spinner_quiz)
        val tvSelectedQuiz: TextView = findViewById(R.id.tv_selected_quiz)
        val quizOptions = arrayOf("Math Quiz", "Gym Quiz", "Howard Quiz")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, quizOptions)

        spinnerQuiz.adapter = adapter
        spinnerQuiz.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedQuiz = parent?.getItemAtPosition(position).toString();
                tvSelectedQuiz.text = "Selected Quiz: $selectedQuiz"
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
                tvSelectedQuiz.text = "No quiz selected."
                selectedQuiz = ""
            }
        }
    }


    private fun setupStartButton() {
        val btnStart: Button = findViewById(R.id.btn_start)
        btnStart.setOnClickListener {
            if (selectedQuiz.isNotBlank()) {
                Toast.makeText(this, "Starting $selectedQuiz", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, QuizActivity::class.java)
                intent.putExtra("quiz", selectedQuiz)
                startActivity(intent)
            } else {
                Toast.makeText(this, "No quiz selected.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}